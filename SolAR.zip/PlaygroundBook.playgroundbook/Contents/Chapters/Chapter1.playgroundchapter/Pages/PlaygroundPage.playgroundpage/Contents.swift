//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

/*:
 Welcome to SolAR, my swift playground book. This is my first time submitting something for WWDC
 */
/*:
 I recommend you to turn up the volume and make sure silent is off. Hold your iPad horizontally for the best experience. I recommend you to make it full screen for the best experience. Look at how the planets spin! FYI, the planets are rotating at different rates! Just like in real life!!
 */

// Images for planets and sun from https://www.solarsystemscope.com/textures/ by Solar System Textures
// Royalty free background music from https://www.youtube.com/watch?v=Tp_0oMPGBZs by Vilkas Sound

/*:
Continue to the next page when you are done here! 😊
*/
