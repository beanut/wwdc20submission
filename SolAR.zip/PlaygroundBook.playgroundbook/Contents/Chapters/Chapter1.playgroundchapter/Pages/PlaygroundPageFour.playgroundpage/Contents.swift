//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
As Earth continues to show its age, humans dream to terraform Mars 😮😮😮. By the way, I recommend you to make it full screen for the best experience. Mars was once a beautiful, habitable planet, just like Earth. But due to unknown reasons, it turned into a rocky, dry planet. There certainly are ways to reverse Mars back but that will be too much effort that we should be looking at other planets. In order to make it habitable again, we must plant, increase the atmospheric pressure,thicken the atmosphere and create a magnetic field.
*/

// Image for Mars from https://www.solarsystemscope.com/textures/ by Solar System Textures
// Royalty free background music from https://www.youtube.com/watch?v=Tp_0oMPGBZs by Vilkas Sound

/*:
Continue to the next page when you are done here! 😊
*/

