//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

/*:
  Look at this triple star system. I recommend you to make it full screen for the best experience. This system consists of Alpha Centauri A (LARGEST), B and Proxima Centauri (SMALLEST). The smallest star has a potentially habitable planet 😮 named Proxima Centauri B which humans might call home in hundreds years to come!! How incredible!
 */

// Image for stars from https://www.solarsystemscope.com/textures/ by Solar System Textures
// Image for teresterial planet from https://opengameart.org/content/10-terrestrial-planet-wrapping-textures by gryphie
// Royalty free background music from https://www.youtube.com/watch?v=Tp_0oMPGBZs by Vilkas Sound

/*:
Continue to the next page when you are done here! 😊
*/
