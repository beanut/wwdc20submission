//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

/*:
Nothing is eternal. Everything has to come to an end 😢. Same applies for planet Earth 😢. As the sun will run out of hydrogen in 5 billion years, it will expand and eat Earth in the next 7 billion years 😢. I recommend you to make it full screen for better experience. See how the sun expands and engulf Mercury, Venus and possibly Earth.
 */

// Images for planets and the Sun from https://www.solarsystemscope.com/textures/ by Solar System Textures
// Royalty free background music from https://www.youtube.com/watch?v=z81A1nbEVug by RealPublic

/*:
Continue to the next page when you are done here! 😊
*/
