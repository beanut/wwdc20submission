//
//  FourthViewController.swift
//  Book_Sources
//
//  Created by Bernard Lim on 17/05/2020.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation

public class FourthViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    @IBOutlet weak var sceneView: ARSCNView!
    private var audioPlayer = AVAudioPlayer()
    private let backgroundSound = URL(fileURLWithPath: Bundle.main.path(forResource: "space", ofType: "mp3")!)
    private let mars = SCNNode(geometry: SCNSphere(radius: 0.11))
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
        createMars()
        sound()
        perform(#selector(upgradeMars), with: nil, afterDelay: 21.5)
        
        let string = "Humankind always have a dream to terraform mars, which is not quite possible using present-day technology. But hypothetically, it’s possible. Mars is the most earth-like planet in the solar system. We must first thicken the atmosphere, plant tress for oxygen and increase the atmospheric pressure of the planet and making a magnetic field. However, that would be too much effort that we should be looking at other habitable planets."
        let utterance = AVSpeechUtterance(string: string)
        utterance.rate = AVSpeechUtteranceMaximumSpeechRate / 2
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")

        let synth = AVSpeechSynthesizer()
        synth.speak(utterance)
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
        audioPlayer.pause()
        audioPlayer.volume = 0.5
    }
    
    //MARK: - Methods
    @objc func upgradeMars() {
        mars.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "proxima.png")
    }
    
    func sound() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: backgroundSound)
            audioPlayer.play()
        } catch {
            // couldn't load file :(
        }
    }
    
    
    func createMars() {
        mars.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "mars.jpg")
        mars.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        mars.position = SCNVector3(0, 0, -0.4)
        let rotateAction = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0,1,0), duration: 10)
        let rotationForeverAction = SCNAction.repeatForever(rotateAction)
        mars.runAction(rotationForeverAction)
        sceneView.scene.rootNode.addChildNode(mars)
    }
    
}
