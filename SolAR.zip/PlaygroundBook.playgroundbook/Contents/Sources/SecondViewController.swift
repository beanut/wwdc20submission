//
//  SecondViewController.swift
//  Book_Sources
//
//  Created by Bernard Lim on 17/05/2020.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation

public class SecondViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    @IBOutlet weak var sceneView: ARSCNView!
    private var sun = SCNNode()
    private var timer: Timer?
    private let backgroundSound = URL(fileURLWithPath: Bundle.main.path(forResource: "expanding", ofType: "mp3")!)
    private var audioPlayer = AVAudioPlayer()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
        makeSun(with: 0.3)
        sound()
        makeMercury()
        makeVenus()
        makeEarth()
        makeMars()
        perform(#selector(sunTimer), with: nil, afterDelay: 5)
        let string = "In about 5 billion years, the sun will run out of hydrogen to burn. With no hydrogen left to fuse in the core, a shell of hydrogen will form around the helium-filled core. Gravitational forces will take over, compressing the core and allowing the rest of the sun to expand for a few billion years and engulf Mercury, Venus and Earth."
        let utterance = AVSpeechUtterance(string: string)
        utterance.rate = AVSpeechUtteranceMaximumSpeechRate / 2
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")

        let synth = AVSpeechSynthesizer()
        synth.speak(utterance)
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
        
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
        audioPlayer.pause()
        
    }
    
    //MARK: - Methods
    
    func sound() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: backgroundSound)
            audioPlayer.play()
            audioPlayer.volume = 0.5
        } catch {
            // couldn't load file :(
        }
    }
    
    @objc func sunTimer() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            self.timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.changeSun), userInfo: nil, repeats: false)
        }
    }
    
    @objc func changeSun() {
        var sunRadius: CGFloat = 0.3
        var counter = 0
        Timer.scheduledTimer(withTimeInterval: 0.08, repeats: true) { timer in
            if counter < 66 {
                self.makeSun(with: sunRadius)
                sunRadius += 0.01
                counter += 1
            }
            if sunRadius == 0.4 || counter > 65 {
                timer.invalidate()
            }
        }
    }
    
    func makeSun(with radius: CGFloat){
        sun = SCNNode(geometry: SCNSphere(radius: radius))
        sun.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "sun.jpg")
        sun.position = SCNVector3(-0.5, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(sun)
    }
    
    func makeMercury() {
        // Planet node
        let mercury = SCNNode(geometry: SCNSphere(radius: 0.02))
        mercury.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "mercury.jpg")
        mercury.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        mercury.position = SCNVector3(-0.1, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(mercury)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 1)
        let runForeverAction = SCNAction.repeatForever(action)
        mercury.runAction(runForeverAction)
    }
    
    func makeVenus() {
        // Planet node
        let venus = SCNNode(geometry: SCNSphere(radius: 0.04))
        venus.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "venus.jpg")
        venus.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        venus.position = SCNVector3(0.05, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(venus)
        let action = SCNAction.rotate(by: -360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 1.2)
        let runForeverAction = SCNAction.repeatForever(action)
        venus.runAction(runForeverAction)
    }
    
    func makeEarth() {
        // Planet node
        let earth = SCNNode(geometry: SCNSphere(radius: 0.11))
        earth.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "earth.jpg")
        earth.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        earth.position = SCNVector3(0.3, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(earth)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 7)
        let runForeverAction = SCNAction.repeatForever(action)
        earth.runAction(runForeverAction)
    }
    
    func makeMars() {
        // Planet node
        let mars = SCNNode(geometry: SCNSphere(radius: 0.09))
        mars.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "mars.jpg")
        mars.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        mars.position = SCNVector3(0.6, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(mars)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 5)
        let runForeverAction = SCNAction.repeatForever(action)
        mars.runAction(runForeverAction)
    }
}
