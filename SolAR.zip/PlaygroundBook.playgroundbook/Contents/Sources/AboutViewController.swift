//
//  AboutViewController.swift
//  Book_Sources
//
//  Created by Bernard Lim on 17/05/2020.
//

import UIKit
import PlaygroundSupport

public class AboutViewController: UIViewController {
    
    @IBOutlet weak var meText: UILabel!
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        meText.text = "Hi Apple Reviewer. I am Bernard Lim from Malaysia 🇲🇾. This is my first time submitting something for WWDC. I'm quite nervous 😬 as I'm still quite new to Swift. If i get awarded with the jackets and pins, I will consider it as a HUGE achievement 🏆. Since 2018, I stayed up late til 2AM to watch WWDC online😂, to witness the announcement of amazing softwares from Apple every year! Unfornately, we can only do it online this year. Anyways, happy to join everyone on 22 June! And have a nice day reviewing swift playgrounds and stay safe 🌞!"
        meText.numberOfLines = 0
        meText.layer.borderColor = UIColor.white.cgColor
        meText.layer.borderWidth = 3
        // Do any additional setup after loading the view.
    }

}
