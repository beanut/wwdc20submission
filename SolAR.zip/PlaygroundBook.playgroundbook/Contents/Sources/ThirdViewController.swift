//
//  ThirdViewController.swift
//  Book_Sources
//
//  Created by Bernard Lim on 17/05/2020.
//
// Teresterial planet texture from https://opengameart.org/content/10-terrestrial-planet-wrapping-textures by gryphie

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation

public class ThirdViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    @IBOutlet weak var sceneView: ARSCNView!
    private var audioPlayer = AVAudioPlayer()
    private let backgroundSound = URL(fileURLWithPath: Bundle.main.path(forResource: "space", ofType: "mp3")!)
    private var proximaCentauri = SCNNode()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
        makeAlphaCentauriA()
        makeAlphaCentauriB()
        makeProximaCentauri()
        makeProximaCentauriB()
        
        let string = "This is a triple star system. It is the closest star system from the sun. It is located about 4 light-years away from us. Consisting of Alpha Centauri A, B and Proxima Centauri. Alpha Centauri A is the largest of all, Proxima Centauri is the smallest. The planet that orbits the smallest star is Proxima Centauri B. It’s well known to be a potentially habitable planet as it is located in its stars habitable zone."
        let utterance = AVSpeechUtterance(string: string)
        utterance.rate = AVSpeechUtteranceMaximumSpeechRate / 2
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")

        let synth = AVSpeechSynthesizer()
        synth.speak(utterance)
        
    }
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
        audioPlayer.pause()
    }

    //MARK: - Methods
    func sound() {
        do {
             audioPlayer = try AVAudioPlayer(contentsOf: backgroundSound)
             audioPlayer.play()
            audioPlayer.volume = 0.5
        } catch {
           // couldn't load file :(
        }
    }
    
    func makeAlphaCentauriA() {
        let sphere = SCNNode(geometry: SCNSphere(radius: 0.09))
        sphere.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "sun.jpg")
        sphere.position = SCNVector3(0, 0, -0.3)
        sceneView.scene.rootNode.addChildNode(sphere)
    }
    
    func makeAlphaCentauriB() {
        let sphere = SCNNode(geometry: SCNSphere(radius: 0.05))
        sphere.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "sun.jpg")
        sphere.position = SCNVector3(0.3, 0, -0.3)
        sceneView.scene.rootNode.addChildNode(sphere)
    }
    
    func makeProximaCentauri() {
        proximaCentauri = SCNNode(geometry: SCNSphere(radius: 0.02))
        proximaCentauri.geometry?.firstMaterial?.diffuse.contents = UIColor.red
        proximaCentauri.position = SCNVector3(0.4, 0, -0.7)
        let rotateAction = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0,1,0), duration: 10)
        let rotationForeverAction = SCNAction.repeatForever(rotateAction)
        proximaCentauri.runAction(rotationForeverAction)
        sceneView.scene.rootNode.addChildNode(proximaCentauri)
    }
    
    func makeProximaCentauriB() {
        let planet = SCNNode(geometry: SCNSphere(radius: 0.009))
        planet.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "proxima.png")
        planet.position = SCNVector3(0.1, 0, -0.1)
        planet.geometry?.firstMaterial?.specular.contents = UIColor.red
        proximaCentauri.addChildNode(planet)
    }

}
