//
//  ThirdViewSupport.swift
//  Book_Sources
//
//  Created by Bernard Lim on 17/05/2020.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation

public func instantiateThirdView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "Third", bundle: nil)

    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("Third.storyboard does not have an initial scene; please set one or update this function")
    }

    guard let liveViewController = viewController as? ThirdViewController else {
        fatalError("Third.storyboard's initial scene is not a LiveViewController; please either update the storyboard or this function")
    }

    return liveViewController
}
