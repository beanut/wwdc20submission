//
//  SecondViewSupport.swift
//  Book_Sources
//
//  Created by Bernard Lim on 17/05/2020.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation

public func instantiateSecondView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "Second", bundle: nil)

    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("Second.storyboard does not have an initial scene; please set one or update this function")
    }

    guard let liveViewController = viewController as? SecondViewController else {
        fatalError("Second.storyboard's initial scene is not a LiveViewController; please either update the storyboard or this function")
    }

    return liveViewController
}
