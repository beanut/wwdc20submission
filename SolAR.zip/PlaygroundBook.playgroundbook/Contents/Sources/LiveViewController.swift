//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation

//@objc(Book_Sources_LiveViewController)
public class LiveViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    @IBOutlet weak var sceneView: ARSCNView!
    private let backgroundSound = URL(fileURLWithPath: Bundle.main.path(forResource: "space", ofType: "mp3")!)
    private var audioPlayer = AVAudioPlayer()
    public override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
        
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
        sound()
        makeSun()
        makeMercury()
        makeVenus()
        makeEarth()
        makeMars()
        makeJupiter()
        makeSaturn()
        makeUranus()
        makeNeptune()
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
        audioPlayer.pause()
    }
    
    //MARK: - Methods
    func sound() {
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: backgroundSound)
            audioPlayer.play()
        } catch {
            // couldn't load file :(
        }
    }
    
    func makeSun(){
        let sun = SCNNode(geometry: SCNSphere(radius: 0.35))
        sun.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "sun.jpg")
        sun.position = SCNVector3(-0.5, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(sun)
    }
    
    func makeMercury() {
        // Planet node
        let mercury = SCNNode(geometry: SCNSphere(radius: 0.03))
        mercury.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "mercury.jpg")
        mercury.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        mercury.position = SCNVector3(-0.1, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(mercury)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 1)
        let runForeverAction = SCNAction.repeatForever(action)
        mercury.runAction(runForeverAction)
    }
    
    func makeVenus() {
        // Planet node
        let venus = SCNNode(geometry: SCNSphere(radius: 0.05))
        venus.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "venus.jpg")
        venus.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        venus.position = SCNVector3(0.05, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(venus)
        let action = SCNAction.rotate(by: -360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 1.2)
        let runForeverAction = SCNAction.repeatForever(action)
        venus.runAction(runForeverAction)
    }
    
    func makeEarth() {
        // Planet node
        let earth = SCNNode(geometry: SCNSphere(radius: 0.13))
        earth.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "earth.jpg")
        earth.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        earth.position = SCNVector3(0.3, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(earth)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 7)
        let runForeverAction = SCNAction.repeatForever(action)
        earth.runAction(runForeverAction)
    }
    
    func makeMars() {
        // Planet node
        let mars = SCNNode(geometry: SCNSphere(radius: 0.11))
        mars.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "mars.jpg")
        mars.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        mars.position = SCNVector3(0.6, 0, -1.5)
        sceneView.scene.rootNode.addChildNode(mars)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 5)
        let runForeverAction = SCNAction.repeatForever(action)
        mars.runAction(runForeverAction)
    }
    
    func makeJupiter() {
        // Planet node
        let jupiter = SCNNode(geometry: SCNSphere(radius: 0.16))
        jupiter.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "jupiter.jpg")
        jupiter.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        jupiter.position = SCNVector3(1, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(jupiter)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 28)
        let runForeverAction = SCNAction.repeatForever(action)
        jupiter.runAction(runForeverAction)
    }
    
    func makeSaturn() {
        // Planet node
        let saturn = SCNNode(geometry: SCNSphere(radius: 0.13))
        saturn.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "saturn.jpg")
        saturn.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        saturn.position = SCNVector3(1.4, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(saturn)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 21)
        let runForeverAction = SCNAction.repeatForever(action)
        saturn.runAction(runForeverAction)
    }
    
    func makeUranus() {
        // Planet node
        let uranus = SCNNode(geometry: SCNSphere(radius: 0.14))
        uranus.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "uranus.jpg")
        uranus.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        uranus.position = SCNVector3(1.7, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(uranus)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 10)
        let runForeverAction = SCNAction.repeatForever(action)
        uranus.runAction(runForeverAction)
    }
    
    func makeNeptune() {
        // Planet node
        let neptune = SCNNode(geometry: SCNSphere(radius: 0.115))
        neptune.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "neptune.jpg")
        neptune.geometry?.firstMaterial?.specular.contents = UIColor.yellow
        neptune.position = SCNVector3(2, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(neptune)
        let action = SCNAction.rotate(by: 360.degreesToRadians(), around: SCNVector3(0, 1, 0), duration: 8)
        let runForeverAction = SCNAction.repeatForever(action)
        neptune.runAction(runForeverAction)
    }
    
}

//MARK: - Extensions
extension Int {
    func degreesToRadians() -> CGFloat {
        return CGFloat(self) * CGFloat.pi / 180
    }
}
